package Redrock.the2time;

import java.util.Scanner;

public class lead{
    Scanner sc = new Scanner(System.in);

    private String name;
    private int atk, health, defence;

    public void input() {
        System.out.println("请输入主角名称:");
        this.name = sc.next();
        System.out.println("请输入主角攻击力:");
        this.atk = sc.nextInt();
        System.out.println("请输入主角生命值:");
        this.health = sc.nextInt();
        System.out.println("请输入主角防御力:");
        this.defence = sc.nextInt();
    }//输入主角属性的方法

    public lead() { }

    public lead(String name, int atk, int health, int defence) {
        this.name = name;
        this.atk = atk;
        this.health = health;
        this.defence = defence;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAtk() {
        return atk;
    }

    public void setAtk(int atk) {
        this.atk = atk;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public int getDefence() {
        return defence;
    }

    public void setDefence(int defence) {
        this.defence = defence;
    }

}


