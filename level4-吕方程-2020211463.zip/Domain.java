package Redrock.the2time;

import java.util.Scanner;

public class Domain {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        fright fright = new fright();//创建对象,一打三模式

        System.out.println("==================");//华丽的分割线
        fright.fright();
    }

}
