package Redrock.the2time;

import java.util.*;

public class fright {

    ArrayList<monster> list = new ArrayList<>();//必须使用集合
    Scanner sc = new Scanner(System.in);
    lead lead = new lead();
    monster monster = new monster();//实例化对象
    fignt_judge fj = new fignt_judge();
    fright_choice fc = new fright_choice();

    int harm, round = 1;//harm为造成的伤害,round为进行的回合数

    public void fright() {
        lead.input();//输入主角的属性
        int at, hea;
        String na;
        for (int i = 1; i <= 2; i++) {
            System.out.println("==================");//华丽的分割线
            System.out.println("请输入怪物" + i + "的名称:");
            na = sc.next();
            System.out.println("请输入怪物" + i + "的攻击力:");
            at = sc.nextInt();
            System.out.println("请输入怪物" + i + "的生命值:");
            hea = sc.nextInt();
            list.add(new monster(na, at, hea));//在集合中new一个怪物类,下标分别为0,1,2
        }//到这里为止，我拥有了三个怪物

        while (list.size() != 0) {
            //三个怪物全死在结束战斗
            int sum = 0;
            System.out.println("第" + round + "回合开始");
            if (lead.getHealth() > 0) {
                System.out.println("你想如何行动,1:随机攻击(伤害增加),2:范围攻击(伤害减少),3:指定攻击(伤害适中)");
                switch (sc.nextInt()) {
                    case 1:
                        fc.randomattack();
                        break;
                    case 2:
                        fc.aoeattack();
                        break;
                    case 3:
                        fc.appointattack();
                        break;
                }//选择战斗方式
            } else {
                System.out.println("你的人物已经死亡,游戏结束");
                break;
            }
            for (int i = 0; i < list.size(); i++) {
                harm = list.get(i).getAtk() - lead.getDefence();
                sum += harm;
            }//计算怪物们的全部攻击力
            lead.setHealth(lead.getHealth() - sum - lead.getDefence());
            System.out.println("怪物们对" + lead.getName() + "造成了" + sum + "点伤害");//此处是怪物们反击主角的方法,这里也不想让主角反击了,感觉会很臃肿
            if(fj.judge(lead.getName(),lead.getHealth())){
                System.out.println(lead.getName() + "已经死亡,游戏结束");
                break;
            }//判断主角在怪物反击之后是否死亡
            System.out.println("第" + round + "回合结束");
            round++;
            System.out.println("===================");
        }//此处是主角对怪物造成伤害
        System.out.println("战斗胜利!你居然胜利了!");
        System.out.println(lead.getName() + "还拥有" + lead.getHealth() + "点血量");
//        for (int i = 0; i < list.size(); i++) {
//            System.out.println(list.get(i).getName() + "还拥有" + list.get(i).getHealth() + "点血量");//显示血量,可以考虑使用比率进行大概表示
//        }
    }

    public class fright_choice {
        Random ra = new Random();

        int harm;

        public void randomattack() {
            harm = 2 * lead.getAtk();
            int num = ra.nextInt(list.size());//取出随机数
            list.get(num).setHealth(list.get(num).getHealth() - harm);
            System.out.println(lead.getName() + "对" + list.get(num).getName() + "造成了" + harm + "点伤害");
            if (fj.judge(list.get(num).getName(), list.get(0).getHealth())) {
                System.out.println(list.get(num).getName() + "已经死亡");
                list.remove(num);
            } else {
                lead.setHealth(fj.frightBack(list.get(num).getName(), list.get(num).getAtk(), lead.getHealth(), lead.getDefence()));
            }
        }//随机攻击的方法,这里可以考虑条用指定攻击的方法以简化代码

        public void aoeattack() {
            harm = lead.getAtk() / list.size();
            for (int i = 0; i < list.size(); i++) {
                list.get(i).setHealth(list.get(i).getHealth() - harm);
                System.out.println(lead.getName() + "对" + list.get(i).getName() + "造成了" + harm + "点伤害");
            }
            for (int i = 0; i < list.size(); i++) {
                if (fj.judge(list.get(i).getName(), list.get(i).getHealth())) {
                    System.out.println(list.get(i).getName() + "已经死亡");
                    list.remove(i);
                }
            }
        }//范围攻击的方法,考虑到了反击十分疼痛,故这里把范围攻击设定为特殊攻击,正好我也轻松些

        public void appointattack() {
            System.out.println("请输入想攻击哪只怪物:(名字)");
            String name = sc.nextLine();
            harm = lead.getAtk();
            for (int i = 0; i < list.size(); i++) {
                if (list.get(i).getName().equals(name)) {
                    list.get(i).setHealth(list.get(i).getHealth() - harm);
                    System.out.println(lead.getName() + "对" + list.get(i).getName() + "造成了" + harm + "点伤害");
                    if (fj.judge(list.get(i).getName(), list.get(i).getHealth())) {
                        list.remove(i);
                    } else {
                        fj.frightBack(list.get(i).getName(), list.get(i).getAtk(), lead.getHealth(), lead.getDefence());
                        if (fj.judge(lead.getName(), lead.getHealth())) {
                            break;//此处游戏人物可能死亡
                        }
                    }
                    break;
                }
            }
        }//指定攻击的方法

        public void live_do() {

        }//显示血条的方法

    }

}