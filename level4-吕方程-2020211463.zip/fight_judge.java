package Redrock.the2time;

public interface fight_judge {
    public boolean judge(String name,int health);
    public void frightBack(String name,int atk,int health);//反击的抽象方法
    public int frightBack(String name,int atk,int health,int defence);//反击的抽象方法
}
