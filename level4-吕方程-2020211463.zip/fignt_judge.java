package Redrock.the2time;

public class fignt_judge implements fight_judge{

    @Override
    public boolean judge(String name, int health) {
        if(health <= 0){
            return true;//返回ture则该人物已经死亡
        }else{
            return false;//返回false则该人物还活着
        }
    }

    @Override
    public void frightBack(String name, int atk, int health) {
        //name是发起反击的方法,atk是攻击力,health是被攻击者的血量
        health -= atk;
        System.out.println(name + "反击造成了" + atk + "点伤害");
    }//这是主角攻击怪物的方法

    @Override
    public int frightBack(String name, int atk, int health, int defence) {
        //name是发起反击的人物,atk是攻击力,health是被攻击者的血量
        int harm = atk - defence;
        health -= harm;
        System.out.println(name + "反击造成了" + harm + "点伤害");
        return health;
    }//这是怪物反击主角的方法

}

