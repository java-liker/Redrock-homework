package Redrock.the2time;

import java.util.Scanner;

public class monster{

    Scanner sc = new Scanner(System.in);
    private String name;
    private int atk,health,num;

    public monster() {
    }

    public monster(String name,int atk,int health) {
        this.name = name;
        this.atk = atk;
        this.health = health;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAtk() {
        return atk;
    }

    public void setAtk(int atk) {
        this.atk = atk;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

}

